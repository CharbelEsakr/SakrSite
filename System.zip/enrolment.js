const enrolment = () => {
  const { useState, useEffect } = React;
  const [enrollments, setEnrollments] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      const response = await fetch('/api/enrolment.php');
      const data = await response.json();

      if (response.ok) {
        setEnrollments(data);
      } else {
        throw new Error('Error fetching enrollment data');
      }
    } catch (error) {
      console.error('Error fetching enrollment data:', error.message);
    }
  }

  const exportToExcel = () => {
    const table = document.getElementById('enrollments-table');
    const rows = table.querySelectorAll('tr');
    let csvContent = '';

    for (const row of rows) {
      const cells = row.querySelectorAll('td, th');
      const rowData = Array.from(cells).map(cell => cell.textContent);
      const encodedRowData = rowData.map(encodeCellData).join(',');
      csvContent += encodedRowData + '\n';
    }

    // Function to encode cell data in UTF-8
    function encodeCellData(data) {
      return '"' + data.replace(/"/g, '""') + '"';
    }

    // Add BOM (Byte Order Mark) to indicate UTF-8 encoding
    const csvData = '\uFEFF' + csvContent;

    // Create a Blob with the CSV data
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });

    // Create a temporary anchor element and trigger the download
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'enrollments.csv';
    link.click();
  };

  return (
    <div>
      <h2>Enrollments</h2>
      <table id="enrollments-table">
        <thead>
          <tr>
            <th>id</th>
            <th>Trainee Name</th>
            <th>Academic Section</th>
            <th>Country</th>
            <th>Cohort</th>
            <th>Course</th>
            <th>Enrolled_At</th>
          </tr>
        </thead>
        <tbody>
          {enrollments.map((enrollment) => (
            <tr key={enrollment.id}>
              <td>{enrollment.id}</td>
              <td>{enrollment.Name}</td>
              <td>{enrollment.academic_section_name}</td>
              <td>{enrollment.country_name}</td>
              <td>{enrollment.cohort_name}</td>
              <td>{enrollment.course_name}</td>
              <td>{enrollment.Enrolled_At}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={exportToExcel}>Export to Excel</button>
    </div>
  );
};
