const fetchTables = () => {
  const { useState, useEffect } = React;
  const [tables, setTables] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTable, setSelectedTable] = useState('');

  useEffect(() => {
    fetchTables();
  }, []);

  const fetchTables = async () => {
    try {
      const response = await axios.get('/api/fetchTables.php');
      setTables(response.data.data);
    } catch (error) {
      console.error('Error fetching tables:', error);
    }
  };

  const searchTable = (tableName) => {
    const searchData = tables[tableName].filter((row) => {
      for (const value of Object.values(row)) {
        if (value.includes(searchQuery)) {
          return true;
        }
      }
      return false;
    });
    // Display the search results in the table
    setTables({ ...tables, [tableName]: searchData });
  };

  const escapeCSVValue = (value) => {
    if (typeof value === 'string') {
      // Escape double quotes by replacing them with two double quotes
      return value.replace(/"/g, '""');
    }
    return value;
  };

  const exportTable = (tableName) => {
    const exportData = tables[tableName];
    if (exportData) {
      const csvContent =
        '\uFEFF' + // Add the UTF-8 BOM (Byte Order Mark) to indicate UTF-8 encoding.
        Object.keys(exportData[0]).join(',') + '\n' +
        exportData.map((row) =>
          Object.values(row).map((value) => `"${escapeCSVValue(value)}"`).join(',')
        ).join('\n');

      // Convert the CSV content to Windows-1256 encoding
      const csvEncoded = new TextEncoder('windows-1256').encode(csvContent);
      const blob = new Blob([csvEncoded], { type: 'text/csv;' });

      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `${tableName}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const deleteRow = async (tableName, id) => {
    try {
      const response = await axios.delete(`/api/fetchTables.php?action=delete&id=${id}&table=${tableName}`);
      if (response.data.success) {
        fetchTables();
      } else {
        console.error('Failed to delete row');
      }
    } catch (error) {
      console.error('Error deleting row:', error);
    }
  };

  const clearTable = () => {
    fetchTables();
    setSelectedTable(selectedTable);
    setSearchQuery('');
  };

  return (
    <div>
      <h2>Tables</h2>
      <select value={selectedTable} onChange={(e) => setSelectedTable(e.target.value)}>
        <option value="">Select a table</option>
        {Object.keys(tables).map((tableName) => (
          <option value={tableName} key={tableName}>{tableName}</option>
        ))}
      </select>
      {selectedTable && (
        <div>
          <h3>{selectedTable}</h3>
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search..." />
          <button onClick={() => searchTable(selectedTable)}>Search</button>
          <button onClick={clearTable}>Clear</button>
          <table>
            <thead>
              <tr>
                {Object.keys(tables[selectedTable][0]).map((column) => (
                  <th key={column}>{column}</th>
                ))}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {tables[selectedTable].map((row, index) => (
                <tr key={index}>
                  {Object.values(row).map((value, index) => (
                    <td key={index}>{value}</td>
                  ))}
                  <td>
                    <button onClick={() => deleteRow(selectedTable, row.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="buttons" onClick={() => exportTable(selectedTable)}>Export</button>
        </div>
      )}
    </div>
  );
};