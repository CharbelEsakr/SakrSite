function createTable() {
     const { useState } = React;
  const [tableName, setTableName] = useState('');
  const [columns, setColumns] = useState([{ name: '', type: '' }]);

  const handleTableNameChange = (e) => {
    setTableName(e.target.value);
  };

  const handleColumnNameChange = (index, e) => {
    const updatedColumns = [...columns];
    updatedColumns[index].name = e.target.value;
    setColumns(updatedColumns);
  };

  const handleColumnTypeChange = (index, e) => {
    const updatedColumns = [...columns];
    updatedColumns[index].type = e.target.value;
    setColumns(updatedColumns);
  };

  const addColumn = () => {
    setColumns([...columns, { name: '', type: '' }]);
  };

  const removeColumn = (index) => {
    const updatedColumns = [...columns];
    updatedColumns.splice(index, 1);
    setColumns(updatedColumns);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const excelData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      // Assuming the first row contains column names and the second row contains data types
      if (excelData.length >= 2) {
        const excelColumns = excelData[0].map((name, index) => ({
          name: name || '',
          type: excelData[1][index] || '',
        }));
        setColumns(excelColumns);
      }
    };

    reader.readAsArrayBuffer(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const confirmed = window.confirm('Are you sure you want to create this table?');
    if (!confirmed) {
      return;
    }
    // Automatically add an "id" column to the columns array
    const updatedColumns = [...columns, { name: 'id', type: 'integer' }];

    try {
      const response = await axios.post('/api/createTable.php', {
        tableName,
        columns: updatedColumns,
      });

      console.log(response.data); // Assuming the server sends a success message
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="container">
      <h2>Create Table</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="table-name">Table Name:</label>
          <input
            id="table-name"
            type="text"
            value={tableName}
            onChange={handleTableNameChange}
          />
        </div>

        <h3>Columns:</h3>
        {columns.map((column, index) => (
          <div className="column-container" key={index}>
            <input
              type="text"
              value={column.name}
              onChange={(e) => handleColumnNameChange(index, e)}
              placeholder="Column Name"
            />
            <input
              type="text"
              value={column.type}
              onChange={(e) => handleColumnTypeChange(index, e)}
              placeholder="Column Type"
            />
            <button type="button" onClick={() => removeColumn(index)}>
              Remove Column
            </button>
          </div>
        ))}

        <button type="button" className="add-column-button" onClick={addColumn}>
          Add Column
        </button>

        {/* Add file input for Excel import */}
        <input type="file" onChange={handleFileChange} accept=".xlsx" />

        <button type="submit" className="create-table-button">
          Create Table
        </button>
      </form>
    </div>
  );
}