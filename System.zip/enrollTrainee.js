const enrollTrainee = () => {
  const { useState, useEffect } = React;
  const [trainees, setTrainees] = useState([]);
  const [countries, setCountries] = useState([]);
  const [cohorts, setCohorts] = useState([]);
  const [courses, setCourses] = useState([]);
  const [academicSections, setAcademicSections] = useState([]);
  const [selectedTrainee, setSelectedTrainee] = useState('');
  const [selectedTraineeId, setSelectedTraineeId] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedCountryId, setSelectedCountryId] = useState('');
  const [selectedCohort, setSelectedCohort] = useState('');
  const [selectedCohortId, setSelectedCohortId] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedCourseId, setSelectedCourseId] = useState('');
  const [selectedAcademicSection, setSelectedAcademicSection] = useState('');
  const [selectedAcademicSectionId, setSelectedAcademicSectionId] = useState('');

  useEffect(() => {
    // Fetch trainees
    fetch('/api/enrollTrainee.php?case=trainees')
      .then((response) => response.json())
      .then((data) => {
        setTrainees(data);
        console.log('Trainees:', data); // Add this logging statement
      })
      .catch((error) => {
        console.error('Error fetching trainees:', error);
      });

    // Fetch countries
    fetch('/api/enrollTrainee.php?case=countries')
      .then((response) => response.json())
      .then((data) => {
        setCountries(data);
        console.log('Countries:', data); // Add this logging statement
      })
      .catch((error) => {
        console.error('Error fetching countries:', error);
      });

    // Fetch cohorts
    fetch('/api/enrollTrainee.php?case=cohorts')
      .then((response) => response.json())
      .then((data) => {
        setCohorts(data);
        console.log('Cohorts:', data); // Add this logging statement
      })
      .catch((error) => {
        console.error('Error fetching cohorts:', error);
      });

    // Fetch courses
    fetch('/api/enrollTrainee.php?case=courses')
      .then((response) => response.json())
      .then((data) => {
        setCourses(data);
        console.log('Courses:', data); // Add this logging statement
      })
      .catch((error) => {
        console.error('Error fetching courses:', error);
      });

    // Fetch academic sections
    fetch('/api/enrollTrainee.php?case=academicSections')
      .then((response) => response.json())
      .then((data) => {
        setAcademicSections(data);
        console.log('Academic Sections:', data); // Add this logging statement
      })
      .catch((error) => {
        console.error('Error fetching academic sections:', error);
      });
  }, []);

  const handleEnroll = () => {
  // Check if all necessary data is selected before proceeding
  if (!selectedTraineeId || !selectedCountryId || !selectedCohortId || !selectedCourseId || !selectedAcademicSectionId) {
    alert('Please select all fields before enrolling.');
    return;
  }

  // Show a confirmation dialog before enrolling
  const isConfirmed = window.confirm('Are you sure you want to enroll this trainee?');
  if (isConfirmed) {
    const enrollmentData = {
      traineeId: selectedTraineeId,
      academicSectionId: selectedAcademicSectionId,
      countryId: selectedCountryId,
      cohortId: selectedCohortId,
      courseId: selectedCourseId,
    };

    fetch('/api/enrollTrainee.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(enrollmentData),
    })
      .then((response) => response.text())
      .then((data) => {
        console.log(data); // Display success message or handle as needed
        alert("Enrollment has been created successfully !");
      })
      .catch((error) => {
        console.error('Error enrolling:', error);
      });
  }
};


  return (
    <div className="container">
      <h2>Enrollment Form</h2>
      <div>
        <label htmlFor="trainee">Trainee:</label>
        <select
          id="trainee"
          value={selectedTraineeId}
          onChange={(e) => {
            setSelectedTraineeId(e.target.value);
          }}
        >
          <option value="">Select Trainee</option>
          {trainees.map((trainee) => (
            <option key={trainee.id} value={trainee.id}>
              {trainee.Name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="country">Country:</label>
        <select
          id="country"
          value={selectedCountryId}
          onChange={(e) => {
            setSelectedCountryId(e.target.value);
          }}
        >
          <option value="">Select Country</option>
          {countries.map((country) => (
            <option key={country.id} value={country.id}>
              {country.country_name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="cohort">Cohort:</label>
        <select
          id="cohort"
          value={selectedCohortId}
          onChange={(e) => {
            setSelectedCohortId(e.target.value);
          }}
        >
          <option value="">Select Cohort</option>
          {cohorts.map((cohort) => (
            <option key={cohort.id} value={cohort.id}>
              {cohort.cohort_name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="course">Course:</label>
        <select
          id="course"
          value={selectedCourseId}
          onChange={(e) => {
            setSelectedCourseId(e.target.value);
          }}
    >
      <option value="">Select Course</option>
      {courses.map((course) => (
        <option key={course.id} value={course.id}>
          {course.course_name}
        </option>
      ))}
    </select>
  </div>
  <div>
    <label htmlFor="academicSection">Academic Section:</label>
    <select
      id="academicSection"
      value={selectedAcademicSectionId}
      onChange={(e) => {
        setSelectedAcademicSectionId(e.target.value);
      }}
    >
      <option value="">Select Academic Section</option>
      {academicSections.map((section) => (
        <option
          key={section.id}
          value={section.id}
        >
          {section.academic_section_name}
        </option>
      ))}
    </select>
  </div>
  <button onClick={handleEnroll}>Enroll</button>
</div>
);
};