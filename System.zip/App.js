const App = () => {
  // Your existing code (useState, useEffect, and other functions)
    const Link = ReactRouterDOM.Link;
    const Route = ReactRouterDOM.Route;
     const { useState } =React;
    const [authenticated, setAuthenticated] = useState(false);
    
  return (
    <div className="App">
    {authenticated ? (
        // Render the app when authenticated
        <React.Fragment>
      <div className="intro">
        <img className="logo" src="/images/THRC.jpeg" alt="logo img" />
        <h1>THRC Data management system</h1>
        <p className="pintro">
          <b>
            Welcome to Mena THRC Data management system !!
            This System is about managing the data tables of different forms in THRC 
          </b>
        </p>
      </div>

<ReactRouterDOM.HashRouter>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/updateTables">updateTables</Link></li>
            <li><Link to="/createTable">createTable</Link></li>
            <li><Link to="/fetchTables">fetchTables</Link></li>
            <li><Link to="/Insert">InsertInto / DeleteTable</Link></li>
            <li><Link to="/InsertExcel">InsertExcel</Link></li>
            <li><Link to="/enrolment">enrolment</Link></li>
            <li><Link to="/enrollTrainee">enrollTrainee</Link></li>
            <li><Link to="/enrollMany">enrollMany</Link></li>
            <li><Link to="/registrationForm">registration Form</Link></li>
            <li><Link to="/emailTrainees">emailTrainees</Link></li>
            </ul>
            <Route path="/" exact component={Home} />
            <Route path="/updateTables" component={updateTables} />
            <Route path="/createTable" component={createTable} />
            <Route path="/fetchTables" component={fetchTables} />
            <Route path="/Insert" component={Insert} />
            <Route path="/InsertExcel" component={InsertExcel} />
            <Route path="/enrolment" component={enrolment} />
            <Route path="/enrollTrainee" component={enrollTrainee} />
            <Route path="/enrollMany" component={enrollMany} />
            <Route path="/registrationForm" component={registrationForm} />
            <Route path="/emailTrainees" component={emailTrainees} />
</ReactRouterDOM.HashRouter>
    
      
    <footer>
      <p>&copy; 2023 Mena THRC. All rights reserved.</p>
    </footer>
     </React.Fragment>
      ) : (
    <Login onLogin={setAuthenticated} />
      )}
    </div>
  );
};
