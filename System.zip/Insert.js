const Insert = () => {
  const { useState, useEffect } = React;
  const [selectedTable, setSelectedTable] = useState("");
  const [insertionRow, setInsertionRow] = useState({});
  const [columns, setColumns] = useState([]);
  const [availableTables, setAvailableTables] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchAvailableTables();
  }, []);

  const fetchAvailableTables = async () => {
    try {
      const response = await axios.get("/api/Insert.php?action=getTables");
      setAvailableTables(response.data);
    } catch (error) {
      console.error("Error fetching available tables:", error);
    }
  };

  const fetchTableColumns = async (tableName) => {
    try {
      const response = await axios.get(`/api/Insert.php?action=getTableColumns&tableName=${tableName}`);
      setColumns(response.data);
    } catch (error) {
      console.error("Error fetching table columns:", error);
    }
  };

  const handleInsert = async () => {
  // Add a prompt to confirm the insert action
  const confirmation = window.confirm("Are you sure you want to insert a new row?");
  if (confirmation) {
    try {
      await axios.post("/api/Insert.php?action=insert", { tableName: selectedTable, row: insertionRow });
      console.log("Row inserted successfully!");
      setInsertionRow({});
      alert("Row inserted successfully!");
    } catch (error) {
      console.error("Error inserting row:", error);
      alert("Failed to insert row. Please try again.");
    }
  }
};

const handleTableDelete = () => {
  if (selectedTable) {
    // Add a prompt to confirm the delete action
    const confirmation = window.confirm("Are you sure you want to delete the selected table?");
    if (confirmation) {
      fetch(`/api/Insert.php?action=delete&tableName=${selectedTable}`, {
        method: 'POST',
      })
      .then(response => response.json())
      .then(data => {
        setMessage(data.message);
        fetchTables();
        alert("Table deleted successfully!");
        // Reload the page after successful deletion
        window.location.reload();
      })
      .catch(error => {
        console.error(error);
        alert("Table deleted successfully!");
         window.location.reload();
      });
    }
  }
};


  return (
    <div>
      <h1>Available Tables</h1>
      <select value={selectedTable} onChange={(e) => { setSelectedTable(e.target.value); fetchTableColumns(e.target.value); }}>
        <option value="">Select a table</option>
        {availableTables.map((table) => (
          <option key={table} value={table}>{table}</option>
        ))}
      </select>
      <button onClick={handleTableDelete}>Delete Table</button>
      {message && <p>{message}</p>}

      {selectedTable && (
        <div className="insertion-row">
          <h2>Insertion Row</h2>
          {columns.map((column) => (
            <div key={column}>
              <label htmlFor={column}>{column}</label>
              <input
                type="text"
                id={column}
                value={insertionRow[column] || ""}
                onChange={(e) => setInsertionRow({ ...insertionRow, [column]: e.target.value })}
              />
            </div>
          ))}
          <button className="buttons" onClick={handleInsert}>
            Insert
          </button>
        </div>
      )}
    </div>
  );
};