const Login = ({ onLogin }) => {
  const { useState } = React;
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Perform authentication here, e.g., checking credentials against a database
    // For simplicity, we'll hardcode the admin credentials here
    if (username === 'Thrc Admins' && password === 'Menathrc!123!') {
      onLogin(true);
    } else {
      alert('Invalid credentials. Please try again.');
    }
  };

  return (
    <div className="login-container">
      <img className="logo" src="/images/THRC.jpeg" alt="logo img" />
      <h1 className="loginh2">Welcome to the Mena THRC Data Management System!</h1>
        <h2 className="loginh2">Kindly log in with your admin credentials :</h2>
      <input className ="loginput"
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input className ="loginput"
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button className ="loginbutton" onClick={handleLogin}>Login</button>
      <footer>
      <p>&copy; 2023 Mena THRC System. All rights reserved.</p>
    </footer>
    </div>
  );
};
