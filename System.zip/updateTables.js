const updateTables = () => {
  const { useState, useEffect } = React;
  const { useTable, useResizeColumns } = 'react-table';
  const [selectedTable, setSelectedTable] = useState("");
  const [tablesData, setTablesData] = useState({});
  const [tableColumns, setTableColumns] = useState([]);
  const [tableData, setTableData] = useState([]);

  const fetchAvailableTables = async () => {
    try {
      const response = await axios.get("/api/index.php?action=getTables");
      const availableTables = response.data;
      setSelectedTable(availableTables[0]); // Set the first table as the selected table
      setTablesData(availableTables.reduce((data, table) => {
        data[table] = [];
        return data;
      }, {}));
    } catch (error) {
      console.error("Error fetching available tables:", error);
    }
  };

 const fetchTableStructure = async (tableName) => {
  try {
    const response = await axios.get(`/api/index.php?action=getTableStructure&table=${tableName}`);
    const tableStructure = response.data;

    console.log(tableStructure); // Log the tableStructure to inspect its value

    if (Array.isArray(tableStructure)) {
      const tableColumns = tableStructure.map((column) => column.Field);
      setTableColumns(tableColumns);
    } else if (typeof tableStructure === 'object') {
      const tableColumns = Object.keys(tableStructure);
      setTableColumns(tableColumns);
    } else {
      console.error("Table structure is not an array or an object:", tableStructure);
    }
  } catch (error) {
    console.error("Error fetching table structure:", error);
  }
};


  const fetchData = async () => {
    try {
      const response = await axios.get(`/api/index.php?action=get&table=${selectedTable}`);
      const tableData = response.data;
      setTableData(tableData);
      setTablesData((prevState) => ({
        ...prevState,
        [selectedTable]: tableData,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchAvailableTables();
  }, []);

  useEffect(() => {
    if (selectedTable) {
      fetchTableStructure(selectedTable);
      fetchData();
    }
  }, [selectedTable]);

  const handleSave = async () => {
    const confirmed = window.confirm("Are you sure you want to save the changes?");

    if (confirmed) {
      try {
        const response = await axios.post(`/api/edit.php?action=update&table=${selectedTable}`, tableData);
        console.log(response.data); // Assuming the API returns a response

        // Optionally, you can fetch the updated data from the server again
        fetchData();
      } catch (error) {
        console.error("Error saving data:", error);
      }
    }
  };

  const handleCellChange = (e, rowIndex, columnName) => {
    const { value } = e.target;
    const newTableData = [...tableData];
    newTableData[rowIndex][columnName] = value;
    setTableData(newTableData);
  };
  

  return (
    <div className="WhistleApp">
      <div className="Title">
        <h1>Update the tables here :</h1>
      </div>
      
      <div className="tableform">
        <h1>kindly select from the tables below in order to update database :</h1>
        <select value={selectedTable} onChange={(e) => setSelectedTable(e.target.value)}>
          <option value="">Select a table</option>
          {Object.keys(tablesData).map((table) => (
            <option key={table} value={table}>{table}</option>
          ))}
        </select>
        <div className="table">
          <table>
            <thead>
              <tr>
                {tableColumns.map((columnName) => (
                  <th key={columnName}>{columnName}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.map((item, rowIndex) => (
                <tr key={item.id}>
                  {tableColumns.map((columnName) => (
                    <td key={columnName}>
                      <textarea
                        type="text"
                        value={item[columnName]}
                        onChange={(e) =>
                          handleCellChange(e, rowIndex, columnName)
                        }
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          <button className="buttons" id="saveButton" onClick={handleSave}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
};
