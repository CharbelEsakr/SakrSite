<?php
// Establish database connection
$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset('utf8');

// Function to fetch registration form data along with questions
function getRegistrations() {
    global $conn;
    
    $sql = "SELECT registration_form.*, 
                   questions.*
            FROM registration_form
            LEFT JOIN questions ON registration_form.id = questions.form_id";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $registrations = array();
        
        while ($row = $result->fetch_assoc()) {
            $registrations[] = $row;
        }
        
        return $registrations;
    }
    
    return array();
}

// Handle registrations
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $registrations = getRegistrations();
    echo json_encode(['registrations' => $registrations], JSON_UNESCAPED_UNICODE); // Output the registrations as JSON
} else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

// Close database connection
$conn->close();
?>
