<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the connection character set to utf8mb4 for Arabic purpose
$conn->set_charset('utf8mb4');

function createTable($tableName, $columns) {
  global $servername, $username, $password, $dbname;
  
  // Create a connection to the database
  $conn = new mysqli($servername, $username, $password, $dbname);
  
  // Check for connection errors
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  
  // Set the connection character set to utf8mb4 for Arabic purpose
$conn->set_charset('utf8mb4');
  
  // Generate the CREATE TABLE statement
  $sql = "CREATE TABLE $tableName (";
  
  // Add column definitions
  foreach ($columns as $column) {
    $columnName = $column['name'];
    $columnType = $column['type'];
    $sql .= "$columnName $columnType, ";
  }
  
  // Remove the trailing comma and space
  $sql = rtrim($sql, ', ');
  
  // Close the CREATE TABLE statement
  $sql .= ")";
  
  // Execute the CREATE TABLE statement
  if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
  } else {
    echo "Error creating table: " . $conn->error;
  }
  
  // Close the database connection
  $conn->close();
}

// Handle the API request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Assuming the request body contains JSON data
  $requestData = json_decode(file_get_contents('php://input'), true);
  
  // Extract the table name, columns, and id from the request data
  $tableName = $requestData['tableName'];
  $columns = $requestData['columns'];
  $id = $requestData['id'];
  
  // Call the createTable function
  createTable($tableName, $columns);
} else {
  echo "Invalid request method";
}

$request_method = $_SERVER["REQUEST_METHOD"];
switch ($request_method) {
    case 'GET':
        if (!empty($_GET["action"])) {
            $action = $_GET["action"];
            if ($action == "get") {
                $sql = "SELECT * FROM incident_report2";
                $result = $conn->query($sql);
                $response = array();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        array_push($response, $row);
                    }
                }
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            }
        }
        break;

    case 'POST':
        if (!empty($_GET["action"]) && $_GET["action"] == "update") {
            // Retrieve the JSON data from the request body
            $json_data = file_get_contents('php://input');
            $data = json_decode($json_data, true);

            foreach ($data as $row) {
                $record_id = $row['id'];
                $FullName = $row['FullName'];
                $phone = $row['phone'];
                $email = $row['email'];
                $description = $row['description'];
                $date = $row['date'];
                $time = $row['time'];
                $location = $row['location'];
                $nameofw = $row['nameofw'];
                $continfo = $row['continfo'];

                $sql = "UPDATE incident_report2 SET FullName = ?, phone = ?, email = ?, description = ?, date = ?, time = ?, location = ?, nameofw = ?, continfo = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssssssi", $FullName, $phone, $email, $description, $date, $time, $location, $nameofw, $continfo, $record_id);
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    // Record updated successfully
                    echo json_encode(array("status" => "success", "message" => "Record updated successfully!"));
                } else {
                    // Failed to update record
                    echo json_encode(array("status" => "error", "message" => "Failed to update record. Error: " . $stmt->error));
                }

                $stmt->close();
            }
        } elseif (!empty($_GET["action"]) && $_GET["action"] == "insert") {
            // Retrieve the JSON data from the request body
            $json_newRecord = file_get_contents('php://input');
            $newRecord = json_decode($json_newRecord, true);

            foreach ($newRecord as $row) {
                $record_id = $row['id'];

                $sql = "INSERT INTO incident_report2 (id) VALUES (?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $record_id);
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    // Record inserted successfully
                    echo json_encode(array("status" => "success", "message" => "Record inserted successfully!"), JSON_UNESCAPED_UNICODE);
                } else {
                    // Failed to insert record
                    echo json_encode(array("status" => "error", "message" => "Failed to insert record. Error: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }

                $stmt->close();
            }
        } elseif (!empty($_GET["action"]) && $_GET["action"] == "createTable") {
            // Retrieve the JSON data from the request body
            $json_data = file_get_contents('php://input');
            $data = json_decode($json_data, true);

            $tableName = $data['tableName'];
            $tableColumns = $data['tableColumns'];

            $sql = "CREATE TABLE $tableName (";
            foreach ($tableColumns as $column) {
                $sql .= "$column VARCHAR(255), ";
            }
            $sql = rtrim($sql, ', ');
            $sql .= ")";

            $response = [];

            if ($conn->query($sql) === TRUE) {
                $response['success'] = true;
                $response['message'] = "Table created successfully";
            } else {
                $response['success'] = false;
                $response['message'] = "Error creating table: " . $conn->error;
            }

            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        }
        break;

    case 'DELETE':
        // Extract the row ID from the request parameter
        $id = $_GET['id'];

        // Perform the deletion operation
        $sql = "DELETE FROM incident_report2 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        // Check if the deletion was successful
        if ($stmt->affected_rows > 0) {
// Return a success response
$response = array('success' => true);
echo json_encode($response);
} else {
// Return an error response
$response = array('success' => false);
echo json_encode($response, JSON_UNESCAPED_UNICODE);
}

$stmt->close();

break;

default:
header("HTTP/1.0 405 Method Not Allowed");
break;
}

$conn->close();

?>