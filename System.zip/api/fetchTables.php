<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the connection character set to utf8mb4 for Arabic purpose
$conn->set_charset('utf8mb4');

$action = isset($_GET['action']) ? $_GET['action'] : '';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$tableName = isset($_GET['table']) ? $_GET['table'] : '';

if ($action === 'delete' && $tableName !== '' && $id !== '') {
    // Use prepared statements for DELETE query
    $stmt = $conn->prepare("DELETE FROM $tableName WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $response = array('success' => true);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    } else {
        $response = array('success' => false);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
    $stmt->close();
} elseif ($action === 'update' && $tableName !== '' && $id !== '') {
    // Handle the update operation
    // ...

} elseif ($action === 'edit' && $tableName !== '' && $id !== '') {
    // Handle the edit operation
    // ...

} else {
    $tables = [];
    $tablesResult = $conn->query("SHOW TABLES");
    while ($tableRow = $tablesResult->fetch_assoc()) {
        $tableName = $tableRow['Tables_in_' . $dbname];
        $tableContent = [];
        $contentResult = $conn->query("SELECT * FROM $tableName");
        while ($contentRow = $contentResult->fetch_assoc()) {
            $tableContent[] = $contentRow;
        }
        $tables[$tableName] = $tableContent;
    }

    $response = [
        'tables' => array_keys($tables),
        'data' => $tables
    ];

    // Encode response as JSON with UTF-8
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
