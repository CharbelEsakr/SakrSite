<?php
// Replace these credentials with your actual database connection details
$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset('utf8');

// Fetch questions from the questionTitles table
$sql = "SELECT id, question_text FROM questionTitles";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $questions = array();
    while ($row = $result->fetch_assoc()) {
        $questions[] = $row;
    }
    // Convert the array to JSON and send the response
    echo json_encode(array("questions" => $questions), JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(array("message" => "No questions found."), JSON_UNESCAPED_UNICODE);
}

// Close the database connection
$conn->close();
?>
