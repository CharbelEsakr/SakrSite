<?php
// Establish database connection
$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset('utf8');


// Function to fetch enrollments
function getEnrollments() {
    header('Content-Type: application/json; charset=utf-8');
    global $conn;
    
    $sql = "SELECT Enrollments.id, registration_form.Name, AcademicSection.academic_section_name, Country.country_name, Cohort.cohort_name, Course.course_name, Enrollments.Enrolled_At
            FROM Enrollments
            INNER JOIN registration_form ON Enrollments.trainee_id = registration_form.id
            INNER JOIN AcademicSection ON Enrollments.academic_section_id = AcademicSection.id
            INNER JOIN Country ON Enrollments.country_id = Country.id
            INNER JOIN Cohort ON Enrollments.cohort_id = Cohort.id
            INNER JOIN Course ON Enrollments.course_id = Course.id";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $enrollments = array();
        
        while ($row = $result->fetch_assoc()) {
            $enrollments[] = $row;
        }
        
        return $enrollments;
    }
    
    return array();
}

// Handle enrollments
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $enrollments = getEnrollments();
    echo json_encode($enrollments, JSON_UNESCAPED_UNICODE); // Output the enrollments as JSON
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the frontend
    $traineeId = $_POST['traineeId'];
    $academicSectionId = $_POST['academicSectionId'];
    $countryId = $_POST['countryId'];
    $cohortId = $_POST['cohortId'];
    $courseId = $_POST['courseId'];
    
    // Insert enrollment record
    $sql = "INSERT INTO Enrollments (trainee_id, academic_section_id, country_id, cohort_id, course_id)
            VALUES ('$traineeId', '$academicSectionId', '$countryId', '$cohortId', '$courseId')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Enrollment created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close database connection
$conn->close();
?>
