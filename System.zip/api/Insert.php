<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the connection character set to utf8mb4
$conn->set_charset('utf8mb4');

$request_method = $_SERVER["REQUEST_METHOD"];
switch ($request_method) {
    case 'GET':
        if (isset($_GET["action"])) {
            $action = $_GET["action"];
            if ($action == "getTables") {
                $sql = "SHOW TABLES";
                $result = $conn->query($sql);
                $response = array();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_row()) {
                        $response[] = $row[0];
                    }
                }
                // Encode response as JSON with UTF-8
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                exit;
            } elseif ($action == "getTableColumns" && isset($_GET["tableName"])) {
                $tableName = $_GET["tableName"];
                $sql = "SHOW COLUMNS FROM $tableName";
                $result = $conn->query($sql);
                $response = array();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $response[] = $row["Field"];
                    }
                }
                // Encode response as JSON with UTF-8
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                exit;
            }
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($_GET["action"])) {
            $action = $_GET["action"];
            if ($action == "insert") {
                $tableName = $data["tableName"];
                $row = $data["row"];

                $columns = implode(", ", array_keys($row));
                $values = "'" . implode("', '", array_values($row)) . "'";

                // Use prepared statements for INSERT query
                $stmt = $conn->prepare("INSERT INTO $tableName ($columns) VALUES ($values)");
                if ($stmt->execute()) {
                    echo json_encode(array("status" => "success", "message" => "Row inserted successfully!"), JSON_UNESCAPED_UNICODE);
                } else {
                    echo json_encode(array("status" => "error", "message" => "Failed to insert row: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
                $stmt->close();
                exit;
            } elseif ($action == "delete" && isset($_GET["tableName"])) {
                $tableName = $_GET["tableName"];
                $sql = "DROP TABLE $tableName";
                if ($conn->query($sql) === TRUE) {
                    echo json_encode(array("status" => "success", "message" => "Table deleted successfully!"), JSON_UNESCAPED_UNICODE);
                } else {
                    echo json_encode(array("status" => "error", "message" => "Table deleted successfully!" . $conn->error), JSON_UNESCAPED_UNICODE);
                }
                exit;
            }
        }
        break;

    default:
        header("HTTP/1.0 405 Method Not Allowed");
        exit;
}

$conn->close();
?>
