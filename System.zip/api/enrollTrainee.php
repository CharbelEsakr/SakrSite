<?php
// Establish database connection
$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset('utf8');
// Function to fetch trainees
function getTrainees() {
    global $conn;

    $sql = "SELECT id, Name FROM registration_form";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $trainees = array();

        while ($row = $result->fetch_assoc()) {
            $trainees[] = $row;
        }

        return $trainees;
    }

    return array();
}

// Function to fetch countries
function getCountries() {
    global $conn;

    $sql = "SELECT id, country_name FROM Country";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $countries = array();

        while ($row = $result->fetch_assoc()) {
            $countries[] = $row;
        }

        return $countries;
    }

    return array();
}

// Function to fetch cohorts
function getCohorts() {
    global $conn;

    $sql = "SELECT id, cohort_name FROM Cohort";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $cohorts = array();

        while ($row = $result->fetch_assoc()) {
            $cohorts[] = $row;
        }

        return $cohorts;
    }

    return array();
}

// Function to fetch courses
function getCourses() {
    global $conn;

    $sql = "SELECT id, course_name FROM Course";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $courses = array();

        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }

        return $courses;
    }

    return array();
}

// Function to fetch academic sections
function getAcademicSections() {
    global $conn;

    $sql = "SELECT id, academic_section_name FROM AcademicSection";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $academicSections = array();

        while ($row = $result->fetch_assoc()) {
            $academicSections[] = $row;
        }

        return $academicSections;
    }

    return array();
}

// Function to enroll trainee
function enrollTrainee($data) {
    global $conn;

    $traineeId = $data['traineeId'];
    $academicSectionId = $data['academicSectionId'];
    $countryId = $data['countryId'];
    $cohortId = $data['cohortId'];
    $courseId = $data['courseId'];

    $sql = "INSERT INTO Enrollments (trainee_id, academic_section_id, country_id, cohort_id, course_id)
            VALUES ('$traineeId', '$academicSectionId', '$countryId', '$cohortId', '$courseId')";

    if ($conn->query($sql) === TRUE) {
        return "Enrollment created successfully";
    } else {
        return "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['case'])) {
        $case = $_GET['case'];
        switch ($case) {
            case 'trainees':
                $trainees = getTrainees();
                echo json_encode($trainees, JSON_UNESCAPED_UNICODE);
                break;
            case 'countries':
                $countries = getCountries();
                echo json_encode($countries, JSON_UNESCAPED_UNICODE);
                break;
            case 'cohorts':
                $cohorts = getCohorts();
                echo json_encode($cohorts, JSON_UNESCAPED_UNICODE);
                break;
            case 'courses':
                $courses = getCourses();
                echo json_encode($courses, JSON_UNESCAPED_UNICODE);
                break;
            case 'academicSections':
                $academicSections = getAcademicSections();
                echo json_encode($academicSections, JSON_UNESCAPED_UNICODE);
                break;
            default:
                echo "Invalid case";
                break;
        }
    } else {
        echo "No case specified";
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $response = enrollTrainee($data);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}

// Close database connection
$conn->close();
?>
