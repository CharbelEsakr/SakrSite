<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Establish database connection
$servername = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$dbname = "menathrc_office";

$conn = new mysqli($servername, $username, $password, $dbname);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

$mail = new PHPMailer(true);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset('utf8');
// Function to fetch trainees
function getTrainees() {
    global $conn;

    $sql = "SELECT id, Name, email FROM registration_form";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $trainees = array();

        while ($row = $result->fetch_assoc()) {
            $trainees[] = $row;
        }

        return $trainees;
    }

    return array();
}


// Handle requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['case'])) {
        $case = $_GET['case'];
        switch ($case) {
            case 'trainees':
                $trainees = getTrainees();
                echo json_encode($trainees, JSON_UNESCAPED_UNICODE);
                break;
            default:
                echo "Invalid case";
                break;
        }
    } else {
        echo "No case specified";
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $selectedEmails = $data["selectedEmails"];
    $subject = $data["subject"];
    $body = $data["body"];
    $footer = $data["footer"];
    $response = emailTrainee($selectedEmails, $subject, $body, $footer, $mail);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}
// This function sends emails to the selected trainees
function emailTrainee($selectedEmails, $subject, $body, $footer, $mail) {
    ob_start();

    try {
        // Server settings
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Specify main and backup SMTP servers
        $mail->SMTPAuth   = true;
        $mail->Username   = 'menathrchost@gmail.com';
        $mail->Password   = 'psaryusrmsbovwmt';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Sender
        $mail->setFrom('menathrchost@gmail.com', 'Mena THRC');

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body . '<br/><br/>' . $footer; // Combine body and footer

        foreach ($selectedEmails as $email) {
            // Recipient
            $mail->clearAddresses();
            $mail->addAddress($email);

            // Send the email
            $mail->send();
            echo "Email sent successfully to: $email\n";
        }
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    ob_end_flush(); // To clear the output buffer
}


// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON payload from the frontend
    $requestData = json_decode(file_get_contents("php://input"), true);

    // Extract data from the payload
    $selectedEmails = $requestData["selectedEmails"];
    $subject = $requestData["subject"];
    $body = $requestData["body"];
    $footer = $requestData["footer"];

}


// Close database connection
$conn->close();
?>