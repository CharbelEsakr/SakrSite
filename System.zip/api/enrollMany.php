<?php
// enrollTrainee.php

// Function to establish a database connection
function connectToDatabase()
{
    $servername = 'localhost';
    $username = 'menathrc_sakr';
    $password = 'JesusisLord470';
    $dbname = 'menathrc_office';

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }
     // Set the connection character set to UTF-8
    $conn->set_charset('utf8');

    return $conn;
}

// Main function to handle the enrollment
function enrollTrainees()
{
    // Set the default charset to UTF-8 for the responses
    header('Content-Type: text/html; charset=utf-8');
    $data = json_decode(file_get_contents('php://input'), true, 512, JSON_UNESCAPED_UNICODE);

    // Get the enrollment data
    $traineeIds = $data['traineeIds'];
    $academicSectionId = $data['academicSectionId'];
    $countryId = $data['countryId'];
    $cohortId = $data['cohortId'];
    $courseId = $data['courseId'];

    // Validate the received data (you can add more validations as needed)
    if (empty($traineeIds) || empty($academicSectionId) || empty($countryId) || empty($cohortId) || empty($courseId)) {
        http_response_code(400);
        echo 'Bad Request: Missing required data.';
        return;
    }

    // Connect to the database
    $conn = connectToDatabase();

    // Prepare and execute the SQL query to insert enrollments
    $sql = 'INSERT INTO Enrollments (trainee_id, academic_section_id, country_id, cohort_id, course_id) VALUES (?, ?, ?, ?, ?)';
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        http_response_code(500);
        echo 'Internal Server Error: Failed to prepare the SQL statement.';
        return;
    }

    // Insert each selected trainee into the Enrollments table
    foreach ($traineeIds as $traineeId) {
        $stmt->bind_param('iiiii', $traineeId, $academicSectionId, $countryId, $cohortId, $courseId);
        $result = $stmt->execute();

        if ($result === false) {
            http_response_code(500);
            echo 'Internal Server Error: Failed to insert enrollment data.';
            return;
        }
    }

    // Close the database connection
    $stmt->close();
    $conn->close();

    // Respond with success message
    http_response_code(200);
    echo json_encode('Enrollment(s) successfully processed.', JSON_UNESCAPED_UNICODE);
    echo 'Enrollment(s) successfully processed.';
}

// Check the request method and call the appropriate function
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    enrollTrainees();
} else {
    http_response_code(405);
    echo 'Method Not Allowed.';
}
?>