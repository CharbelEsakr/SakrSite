<?php

// Set the appropriate database credentials
$host = "localhost";
$username = "menathrc_sakr";
$password = "JesusisLord470";
$database = "menathrc_office";

// Create a database connection
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the GET request to fetch the data for a specific table
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get' && isset($_GET['table'])) {
    $table = $_GET['table'];
    $sql = "SELECT * FROM $table";
    $result = $conn->query($sql);
    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    echo json_encode($data);
}

// Handle the POST request to update the data for a specific table
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'update' && isset($_GET['table'])) {
    $table = $_GET['table'];
    $data = json_decode(file_get_contents('php://input'), true);
    
    foreach ($data as $row) {
        $sql = "UPDATE $table SET ";
        $values = [];
        foreach ($row as $key => $value) {
            $values[] = "$key = '$value'";
        }
        $sql .= implode(', ', $values);
        $sql .= " WHERE id = '" . $row['id'] . "'";
        $conn->query($sql);
    }
    
    echo "Data updated successfully";
}

// Handle the POST request to insert a new row into a specific table
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'insert' && isset($_GET['table'])) {
    $table = $_GET['table'];
    $data = json_decode(file_get_contents('php://input'), true);
    
    $columns = implode(', ', array_keys($data[0]));
    $values = [];
    foreach ($data as $row) {
        $rowValues = [];
        foreach ($row as $value) {
            $rowValues[] = "'$value'";
        }
        $values[] = '(' . implode(', ', $rowValues) . ')';
    }
    $values = implode(', ', $values);
    
    $sql = "INSERT INTO $table ($columns) VALUES $values";
    $conn->query($sql);
    
    echo "Data inserted successfully";
}

// Handle the DELETE request to delete a row from a specific table
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['table']) && isset($_GET['id'])) {
    $table = $_GET['table'];
    $id = $_GET['id'];
    $sql = "DELETE FROM $table WHERE id = '$id'";
    $conn->query($sql);
    
    $response = ['success' => true];
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
