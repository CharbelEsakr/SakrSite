const Home = () => {
  return (
    <div>
      <h2>Welcome to the Home Page</h2>
      <p>This is the content of the home page.</p>
      <h1>   HOME PAGE </h1>
    </div>

  );
};