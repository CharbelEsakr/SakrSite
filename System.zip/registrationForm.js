const registrationForm = () => {
  const { useState, useEffect } = React;
  const [registrations, setRegistrations] = useState([]);
  const [questions, setQuestions] = useState([]);

  useEffect(() => {
    fetchData();
    fetchQuestions();
  }, []);

  async function fetchData() {
    try {
      const response = await fetch('/api/registrationForm.php');
      const data = await response.json();

      if (response.ok) {
        setRegistrations(data.registrations);
      } else {
        throw new Error('Error fetching enrollment data');
      }
    } catch (error) {
      console.error('Error fetching enrollment data:', error.message);
    }
  }
  async function fetchQuestions() {
    try {
      const response = await fetch('/api/questionTitles.php');
      const data = await response.json();

      if (response.ok) {
        setQuestions(data.questions);
      } else {
        throw new Error('Error fetching questions');
      }
    } catch (error) {
      console.error('Error fetching questions:', error.message);
    }
  }

  const exportToExcel = () => {
    const table = document.getElementById('registration-Form');
    const rows = table.querySelectorAll('tr');
    let csvContent = '';

    for (const row of rows) {
      const cells = row.querySelectorAll('td, th');
      const rowData = Array.from(cells).map(cell => cell.textContent);
      const encodedRowData = rowData.map(encodeCellData).join(',');
      csvContent += encodedRowData + '\n';
    }

    // Function to encode cell data in UTF-8
    function encodeCellData(data) {
      return '"' + data.replace(/"/g, '""') + '"';
    }

    // Add BOM (Byte Order Mark) to indicate UTF-8 encoding
    const csvData = '\uFEFF' + csvContent;

    // Create a Blob with the CSV data
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });

    // Create a temporary anchor element and trigger the download
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'registrationForm.csv';
    link.click();
  };

  return (
    <div>
      <h2>Registration Form</h2>
      <table id="registration-Form">
        <thead>
          <tr>
            <th>id</th>
            <th>Trainee Name</th>
            <th>Father's Name</th>
            <th>Work</th>
            <th>Sex</th>
            <th>Birthdate</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Country</th>
            <th>City</th>
            <th>Mother Language</th>
            <th>Other Languages</th>
            {/* Render questions dynamically */}
            {questions.map((question, index) => (
              <th key={index}>{question.question_text}</th>
            ))}
            <th>Enrolled_At</th>
          </tr>
        </thead>
        <tbody>
          {registrations.map((registration_form) => (
            <tr key={registration_form.id}>
              <td>{registration_form.id}</td>
              <td>{registration_form.Name}</td>
              <td>{registration_form.fatherName}</td>
              <td>{registration_form.work}</td>
              <td>{registration_form.sex}</td>
              <td>{registration_form.birthdate}</td>
              <td>{registration_form.phone}</td>
              <td>{registration_form.email}</td>
              <td>{registration_form.country}</td>
              <td>{registration_form.city}</td>
              <td>{registration_form.motherlanguage}</td>
              <td>{registration_form.otherlanguages}</td>
              {/* Render questions dynamically */}
              {[...Array(24)].map((_, index) => (
                <td key={index}>{registration_form[`question${index + 1}`]}</td>
              ))}
              {/* ... */}
              <td>{registration_form.Enrolled_At}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={exportToExcel}>Export to Excel</button>
    </div>
  );
};
