const enrollMany = () => {
  const { useState, useEffect } = React;
  const [trainees, setTrainees] = useState([]);
  const [countries, setCountries] = useState([]);
  const [cohorts, setCohorts] = useState([]);
  const [courses, setCourses] = useState([]);
  const [academicSections, setAcademicSections] = useState([]);
  const [selectedTraineeIds, setSelectedTraineeIds] = useState([]);
  const [selectedCountryId, setSelectedCountryId] = useState('');
  const [selectedCohortId, setSelectedCohortId] = useState('');
  const [selectedCourseId, setSelectedCourseId] = useState('');
  const [selectedAcademicSectionId, setSelectedAcademicSectionId] = useState('');

  useEffect(() => {
    // Fetch trainees
    fetch('/api/enrollTrainee.php?case=trainees')
      .then((response) => response.json())
      .then((data) => {
        setTrainees(data);
        console.log('Trainees:', data);
      })
      .catch((error) => {
        console.error('Error fetching trainees:', error);
      });

    // Fetch countries
    fetch('/api/enrollTrainee.php?case=countries')
      .then((response) => response.json())
      .then((data) => {
        setCountries(data);
        console.log('Countries:', data);
      })
      .catch((error) => {
        console.error('Error fetching countries:', error);
      });

    // Fetch cohorts
    fetch('/api/enrollTrainee.php?case=cohorts')
      .then((response) => response.json())
      .then((data) => {
        setCohorts(data);
        console.log('Cohorts:', data);
      })
      .catch((error) => {
        console.error('Error fetching cohorts:', error);
      });

    // Fetch courses
    fetch('/api/enrollTrainee.php?case=courses')
      .then((response) => response.json())
      .then((data) => {
        setCourses(data);
        console.log('Courses:', data);
      })
      .catch((error) => {
        console.error('Error fetching courses:', error);
      });

    // Fetch academic sections
    fetch('/api/enrollTrainee.php?case=academicSections')
      .then((response) => response.json())
      .then((data) => {
        setAcademicSections(data);
        console.log('Academic Sections:', data);
      })
      .catch((error) => {
        console.error('Error fetching academic sections:', error);
      });
  }, []);

  const handleTraineeCheckboxChange = (e, traineeId) => {
    const isChecked = e.target.checked;
    setSelectedTraineeIds((prevSelectedIds) => {
      if (isChecked) {
        return [...prevSelectedIds, traineeId];
      } else {
        return prevSelectedIds.filter((id) => id !== traineeId);
      }
    });
  };

  const handleEnroll = () => {
      // Client-side validation before submitting the form
    if (
      selectedTraineeIds.length === 0 ||
      !selectedCountryId ||
      !selectedCohortId ||
      !selectedCourseId ||
      !selectedAcademicSectionId
    ) {
      alert('Please fill in all required fields.');
      return;
    }
  // Check if any trainees are selected before proceeding with the enrollment
  if (selectedTraineeIds.length === 0) {
    alert('Please select at least one trainee to enroll.');
    return;
  }

  // Display a confirmation prompt
  const confirmed = window.confirm('Are you sure you want to enroll the selected trainees?');

  if (!confirmed) {
    return; // Don't proceed with the enrollment if not confirmed
  }

  const enrollmentData = {
    traineeIds: selectedTraineeIds,
    academicSectionId: selectedAcademicSectionId,
    countryId: selectedCountryId,
    cohortId: selectedCohortId,
    courseId: selectedCourseId,
  };

  fetch('/api/enrollMany.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(enrollmentData),
  })
    .then((response) => response.text())
    .then((data) => {
      console.log(data); // Display success message or handle as needed
      alert("Selected Trainee(s) have been successfully enrolled !");
    })
    .catch((error) => {
      console.error('Error enrolling:', error);
    });
};

  return (
    <div className="container">
      <h2>Enrollment Form</h2>
      <label>Trainees:</label>
      <div class="checkbox-container">
        {trainees.map((trainee) => (
          <div class="checkbox-item" key={trainee.id}>
            <input
              type="checkbox"
              id={`trainee_${trainee.id}`}
              value={trainee.id}
              checked={selectedTraineeIds.includes(trainee.id)}
              onChange={(e) => handleTraineeCheckboxChange(e, trainee.id)}
            />
            <label htmlFor={`trainee_${trainee.id}`}>{trainee.Name}</label>
          </div>
        ))}
      </div>
      <div>
        <label htmlFor="country">Country:</label>
        <select
          id="country"
          value={selectedCountryId}
          onChange={(e) => {
            setSelectedCountryId(e.target.value);
          }}
          required
        >
          <option value="">Select Country</option>
          {countries.map((country) => (
            <option key={country.id} value={country.id}>
              {country.country_name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="cohort">Cohort:</label>
        <select
          id="cohort"
          value={selectedCohortId}
          onChange={(e) => {
            setSelectedCohortId(e.target.value);
          }}
          required
        >
          <option value="">Select Cohort</option>
          {cohorts.map((cohort) => (
            <option key={cohort.id} value={cohort.id}>
              {cohort.cohort_name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="course">Course:</label>
        <select
          id="course"
          value={selectedCourseId}
          onChange={(e) => {
            setSelectedCourseId(e.target.value);
          }}
          required
        >
          <option value="">Select Course</option>
          {courses.map((course) => (
            <option key={course.id} value={course.id}>
              {course.course_name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="academicSection">Academic Section:</label>
        <select
          id="academicSection"
          value={selectedAcademicSectionId}
          onChange={(e) => {
            setSelectedAcademicSectionId(e.target.value);
          }}
          required
        >
          <option value="">Select Academic Section</option>
          {academicSections.map((section) => (
            <option key={section.id} value={section.id}>
              {section.academic_section_name}
            </option>
          ))}
        </select>
      </div>
      <button onClick={handleEnroll}>Enroll</button>
    </div>
  );
};
