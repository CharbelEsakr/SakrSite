const emailTrainees = () => {
    const { useState, useEffect } =React;
  const [trainees, setTrainees] = useState([]);
  const [emails, setEmails] = useState([]);
  const [selectedTraineeIds, setSelectedTraineeIds] = useState([]);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [footer, setFooter] = useState('');

  useEffect(() => {
    // Fetch trainees
    fetch('/api/emails.php?case=trainees')
      .then((response) => response.json())
      .then((data) => {
        setTrainees(data);
        console.log('Trainees:', data);
      })
      .catch((error) => {
        console.error('Error fetching trainees:', error);
      });

  }, []);

  const handleTraineeCheckboxChange = (e, id) => {
    const isChecked = e.target.checked;
    setSelectedTraineeIds((prevSelectedIds) => {
      if (isChecked) {
        return [...prevSelectedIds, id];
      } else {
        return prevSelectedIds.filter((id) => id !== id);
      }
    });
  };

  const sendEmails = () => {
      if (!subject || !body || !footer) {
    alert('Please fill out all fields (Subject, Body, and Footer) before sending emails.');
    return;
  }
  // Filter the trainees based on selectedTraineeIds
  const selectedTrainees = trainees.filter((trainee) =>
    selectedTraineeIds.includes(trainee.id)
  );

  // Extract the email addresses of selected trainees
  const selectedEmails = selectedTrainees.map((trainee) => trainee.email);

  // Send custom message with subject, body, and footer to the selectedEmails
  const customMessage = `Subject: ${subject}\n\n${body}\n\n${footer}`;
  console.log('Custom Message:', customMessage);
  console.log('Selected Emails:', selectedEmails);

  // Implement the email sending logic here using a library or backend API.
  // For security reasons, sending emails directly from the frontend is not recommended.
  // You can send the selectedEmails and customMessage to the backend API to handle email sending.
  fetch('/api/emails.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      selectedEmails,
      subject,
      body,
      footer,
    }),
  })
    .then((response) => response.text())
    .then((data) => {
      console.log(data); // Response from the backend API
      // Reset the selection and message fields after sending emails
      setSelectedTraineeIds([]);
      setSubject('');
      setBody('');
      setFooter('');
      alert("Emails have been successfully sent !");
    })
    .catch((error) => {
      console.error('Error sending emails:', error);
    });
};


  return (
    <div className="container">
      <h2>Email Form</h2>
      <label>Trainees:</label>
      <div className="checkbox-container">
        {trainees.map((trainee) => (
          <div className="checkbox-item" key={trainee.id}>
            <input
              type="checkbox"
              id={`trainee_${trainee.id}`}
              value={trainee.id}
              checked={selectedTraineeIds.includes(trainee.id)}
              onChange={(e) => handleTraineeCheckboxChange(e, trainee.id)}
            />
            <label htmlFor={`trainee_${trainee.id}`}>{trainee.Name}</label>
          </div>
        ))}
      </div>
      <div>
        <label>Subject:</label>
        <input
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
        <label>Body:</label>
        <textarea value={body} onChange={(e) => setBody(e.target.value)} />
        <label>Footer:</label>
        <textarea value={footer} onChange={(e) => setFooter(e.target.value)} />
      </div>
      <button onClick={sendEmails}>Email Trainees</button>
    </div>
  );
};
