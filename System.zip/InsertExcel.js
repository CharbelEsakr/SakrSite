const InsertExcel = () => {
  const { useState, useEffect } = React;
  const [selectedTable, setSelectedTable] = useState('');
  const [insertionRow, setInsertionRow] = useState([]);
  const [columns, setColumns] = useState([]);
  const [availableTables, setAvailableTables] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchAvailableTables();
  }, []);

  const fetchAvailableTables = async () => {
    try {
      const response = await axios.get('/api/Insert.php?action=getTables');
      setAvailableTables(response.data);
    } catch (error) {
      console.error('Error fetching available tables:', error);
    }
  };

  const fetchTableColumns = async (tableName) => {
    try {
      const response = await axios.get(`/api/Insert.php?action=getTableColumns&tableName=${tableName}`);
      setColumns(response.data);
    } catch (error) {
      console.error('Error fetching table columns:', error);
    }
  };

  const handleInsert = async () => {
    try {
      await Promise.all(
        insertionRow.map((row) => axios.post('/api/Insert.php?action=insert', { tableName: selectedTable, row }))
      );
      console.log('Rows inserted successfully!');
      setInsertionRow([]);
    } catch (error) {
      console.error('Error inserting rows:', error);
    }
  };

  const handleTableDelete = () => {
    if (selectedTable) {
      fetch(`/api/Insert.php?action=delete&tableName=${selectedTable}`, {
        method: 'POST',
      })
        .then((response) => response.json())
        .then((data) => {
          setMessage(data.message);
          fetchTables();
        })
        .catch((error) => console.error(error));
    }
  };

  const handleFileChange = (e) => {
  const file = e.target.files[0];
  const reader = new FileReader();

  reader.onload = (event) => {
    const workbook = XLSX.read(event.target.result, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    if (jsonData.length > 0) {
      const headerRow = jsonData[0]; // Get the header row directly from Excel
      const dataRows = jsonData.slice(1); // Remove the header row from data rows
      const rows = dataRows.map((row) => {
        const rowData = {};
        headerRow.forEach((column, index) => {
          rowData[column] = row[index];
        });
        return rowData;
      });

      setColumns(headerRow);
      setInsertionRow(rows);
    }
  };

  reader.readAsBinaryString(file);
};

  return (
    <div>
      <h1>Available Tables</h1>
      <select
        value={selectedTable}
        onChange={(e) => {
          setSelectedTable(e.target.value);
          fetchTableColumns(e.target.value);
        }}
      >
        <option value="">Select a table</option>
        {availableTables.map((table) => (
          <option key={table} value={table}>
            {table}
          </option>
        ))}
      </select>
      <button onClick={handleTableDelete}>Delete Table</button>
      {message && <p>{message}</p>}

      {selectedTable && (
      <div className="insertion-row">
        <h2>Insertion Rows</h2>
        <input type="file" onChange={handleFileChange} accept=".xlsx, .xls" />
        {/* Display the columns exactly as they appear in Excel */}
        {columns.map((column) => (
          <div key={column}>
            <label htmlFor={column}>{column}</label>
            {insertionRow.map((rowData, index) => (
              <input
                key={`${column}-${index}`}
                type="text"
                id={`${column}-${index}`}
                value={rowData[column] || ''}
                onChange={(e) => {
                  const updatedRows = [...insertionRow];
                  updatedRows[index] = { ...updatedRows[index], [column]: e.target.value };
                  setInsertionRow(updatedRows);
                }}
              />
            ))}
          </div>
        ))}
        <button className="buttons" onClick={handleInsert}>
          Insert
        </button>
      </div>
    )}
  </div>
);
};